package com.pieces;

public interface MyObserver {
    public void saveUpdate(Position initialPosition, Position targetPosition);
}
