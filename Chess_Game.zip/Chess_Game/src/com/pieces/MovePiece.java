package com.pieces;

public enum MovePiece {
    PAWN, KING, KNIGHT, CROSS, DIAGONALLY
}
