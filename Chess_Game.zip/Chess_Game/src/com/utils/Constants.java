package com.utils;

public class Constants {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 800;
    public static final int NO_CELLS = 8;
}
